public class PlayingCard implements IPlayingCard{
	
	// Instance Variables
	
	protected String Suit;
	protected String Rank;
	
	// Implementing the getSuit method from the interface
	public String getSuit() {
		
		return Suit;
		
	}
	// Implementing the getRank method from the interface
	public String getRank() {

		return Rank;
	}
	
	// Implementing the compareTo method form the Comparable interface
	public int compareTo(PlayingCard aCard) {
		if (this.Suit.equals(aCard.Suit) && this.Rank.equals(aCard.Rank)) {
			return 1;
		}
		return 0;
		
	}
	
	// Constructor for a playing card
	public PlayingCard(int aSuit, int aRank) {
		if (aRank == 0) {
			Rank = "Two";
		}
		if (aRank == 1) {
			Rank = "Three";
		}
		if (aRank == 2) {
			Rank = "Four";
		}
		if (aRank == 3) {
			Rank = "Five";
		}
		if (aRank == 4) {
			Rank = "Six";
		}
		if (aRank == 5) {
			Rank = "Seven";
		}
		if (aRank == 6) {
			Rank = "Eight";
		}
		if (aRank == 7) {
			Rank = "Nine";
		}
		if (aRank == 8) {
			Rank = "Ten";
		}
		if (aRank == 9) {
			Rank = "Jack";
		}
		if (aRank == 10) {
			Rank = "Queen";
		}
		if (aRank == 11) {
			Rank = "King";
		}
		else {
			Rank = "Ace";
		}
		if (aSuit == 0) {
			Suit = "Diamonds";
		}
		if (aSuit == 1) {
			Suit = "Hearts";
		}
		if (aSuit == 2) {
			Suit = "Clubs";
		}
		else {
			Suit = "Spades";
		}
	}

}

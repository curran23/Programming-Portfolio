import java.awt.*;
import javax.swing.*;

public class PlayingCardPanel extends JPanel {
	
	/**
	 * This class will display the card as text, and will have the display next card button
	 * that will allow the user to see the next card in the deck.
	 */

	
	//----------------------------------------------------------------------------------
    // Instance Variables
	//----------------------------------------------------------------------------------
		private PlayingCard myDeck;
		int aSuit;
		int aRank;

	//----------------------------------------------------------------------------------
    // Constructors
	//----------------------------------------------------------------------------------
	
		public PlayingCardPanel() {
			
			myDeck = new PlayingCard(aSuit, aRank);
			
			this.setBackground(Color.white);
			this.setPreferredSize(new Dimension(150, 150));
			//this.setLocation(150, 100);
			
		}
	
	
	//----------------------------------------------------------------------------------
    //Class Methods
    //----------------------------------------------------------------------------------
		
		public void drawTopCard() {
			repaint();
		}
		
		public void paintComponent(Graphics g) {
			
			super.paintComponents(g);
			
			int panelWidth = this.getWidth();
			int panelHeight = this.getHeight();
			
			g.drawRect(25, 30, panelWidth - 35, panelHeight - 35);
			
			g.drawString(myDeck.getRank() + " of " + myDeck.getSuit(),40, 80);
		}
		
}




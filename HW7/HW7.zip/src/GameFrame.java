import java.awt.*;
import javax.swing.*;
import java.awt.event.*;



public class GameFrame extends JFrame {

	/** This class will contain the card represented as text with a button that will
	 * display the next card in the deck.
	 * @author Curran Lipsett
	 * @date March 25 2013
	 */
	
	//----------------------------------------------------------------------------------
    // Instance Variables
	//----------------------------------------------------------------------------------
		private PlayingCardPanel gamePanel;
		private JPanel field;
		private JPanel menu;
	
	//----------------------------------------------------------------------------------
    // Constructors
	//---------------------------------------------------------------------------------- 
		public GameFrame() {
			
			// Default frame constructor for the Playing Cards
			this.setSize(300,300);
			this.setTitle("Curran Lipsett Random Cards");
			
			this.createFieldPanel();
			this.createMenuPanel();
			
			this.add(field);
			this.add(menu);
			
			
		}
	
	//----------------------------------------------------------------------------------
    // Helpers
	//----------------------------------------------------------------------------------    
    
		public void createMenuPanel() {
			
			//Set up the menu area.
		    menu = new JPanel();
		    menu.setBounds(0, 300, 250, 100);
		   
	}
	
		public void createFieldPanel() {
			
			//Set up the card field area.
	        field = new JPanel();
	        field.setBounds(0,0,250,200);
	        
	       
	        //Create the card and add it.
	        gamePanel = new PlayingCardPanel();
	        
	        //Create a button and add a listener to it.
		    JButton draw = new JButton("Draw Card Here");
		    draw.setSize(50,20);
		    draw.addActionListener(new ClickListener());
			
		    // Add the button and the game panel to the frame
	        field.add(gamePanel);
	        field.add(draw);
		}
		
		private class ClickListener implements ActionListener 
		   {
		       public void actionPerformed(ActionEvent e) 
		       {
		    	  gamePanel.drawTopCard();
		       }
		   }
		
}

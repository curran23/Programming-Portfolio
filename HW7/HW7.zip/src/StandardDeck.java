public class StandardDeck implements IDeck {
	
	// Instance Variables
	IPlayingCard myDeck[] = new IPlayingCard[52];
	int cardsRemaining = 51;
	IPlayingCard[] myNewDeck = new IPlayingCard[52];
	private int numCards = 52;
	
	int Suit[] = {0,1,2,3};
	int Rank[] = {0,1,2,3,4,5,6,7,8,9,10,11,12};
	
	// Implementing the reset method of the interface
	public void reset() {
		StandardDeck myDeck = new StandardDeck();
		}
	
	// Implementing the shuffle method of the interface
	public void shuffle() {
		
	}
	
	// Implementing the drawTopCard method of the interface
	public PlayingCard drawTopCard() {
		if (numCards != 0) {
			PlayingCard myNewCard = (PlayingCard) myNewDeck[cardsRemaining];
			cardsRemaining --;
			numCards --;
			
			return myNewCard;
		}
		else {
			return null;
		}
	}
	
	// Constructor for a standard deck of cards
	public StandardDeck() {
		
		int myIndex = 0;
		
		for (int suit: Suit) {
			for (int rank: Rank) {
				myDeck[myIndex] = new PlayingCard(suit, rank);
				myIndex++;
			}
		}
		

	}
	
	
}

public class BSTTester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Node x = new Node(5);
		x.add(3);
		x.add(7);
		x.add(100);
		System.out.println(x.toString());
		

	}

}

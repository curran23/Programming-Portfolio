import java.util.*;
import java.io.*;

public class GameApp {

	/** Author : Curran Lipsett
	 Date : 3/24/2013
	 Version : 1.0
	 This program will display a card from a standard card deck in a separate panel
	 for the user to see. It will also have a button that will allow the user to display
	 the next card in the deck.*/
	
	/**
	 * @param args
	 */
	
	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub

		
		GameFrame aCard = new GameFrame();
		aCard.setVisible(true);
		
		}
	}
